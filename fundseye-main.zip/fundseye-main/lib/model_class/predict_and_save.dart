import 'dart:io';
import 'dart:typed_data';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;


Future<void> predictAndSavePatient({
  required String name,
  required String age,
  required String gender,
  required XFile imageFile,
}) async {
  try {
    
    final interpreter = await Interpreter.fromAsset('assets/model.tflite');
    print(" Model loaded successfully");


    // Prepare input/output tensors
    var inputShape = interpreter.getInputTensor(0).shape;
    var outputShape = interpreter.getOutputTensor(0).shape;
    print(" Input Shape: $inputShape | Output Shape: $outputShape");

    // Load and decode image
    final bytes = await File(imageFile.path).readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw Exception(" Image decoding failed");

    final resized = img.copyResize(decoded, width: 224, height: 224);
    print(" Image resized to 224x224");

    final input = _imageToFloat32List(resized);
    final inputBuffer = input.buffer.asFloat32List();
    final inputTensor = inputBuffer.reshape([1, 224, 224, 3]);
    final output = List.filled(outputShape.reduce((a, b) => a * b), 0.0).reshape(outputShape);

    // Inference
    interpreter.run(inputTensor, output);
    interpreter.close();

    // Get result
    final List<double> probabilities = List<double>.from(output[0]);
    print(" Model output: $probabilities");

    final index = probabilities.indexWhere((e) => e == probabilities.reduce((a, b) => a > b ? a : b));
    final condition = _getCondition(index);
    final advice = _getAdvice(index);
    print(" Condition: $condition | 🩺 Advice: $advice");

    // Save to Firestore
    final userId = FirebaseAuth.instance.currentUser!.uid;
    await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('patients')
        .add({
      'name': name,
      'age': age,
      'gender': gender,
      'result': condition,
      'advice': advice,
      'createdAt': FieldValue.serverTimestamp(),
    });

    print(" Data saved to Firestore successfully.");
  } catch (e) {
    print(' Prediction error: $e');
    rethrow;
  }
}

//  Add this in the same file
Float32List _imageToFloat32List(img.Image image) {
  const inputSize = 224;
  final Float32List result = Float32List(inputSize * inputSize * 3);
  int index = 0;

  for (int y = 0; y < inputSize; y++) {
    for (int x = 0; x < inputSize; x++) {
      final pixel = image.getPixel(x, y);
      result[index++] = pixel.r / 255.0;
      result[index++] = pixel.g / 255.0;
      result[index++] = pixel.b / 255.0;
    }
  }

  return result;
}

String _getCondition(int idx) => [
  'No Diabetic Retinopathy',
  'Mild Diabetic Retinopathy',
  'Moderate Diabetic Retinopathy',
  'Severe Diabetic Retinopathy',
  'Proliferative Diabetic Retinopathy'
].elementAt(idx.clamp(0, 4));

String _getAdvice(int idx) => [
  'Maintain a healthy lifestyle. Regular checkups advised.',
  'Watch diet and monitor blood sugar regularly.',
  'Consult an ophthalmologist soon.',
  'Seek specialist attention immediately.',
  'Critical stage. Urgent treatment recommended.'
].elementAt(idx.clamp(0, 4));
