import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HowToUseScreen extends StatelessWidget {
  const HowToUseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'How to Use the App',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Getting Started with FundsEye',
              style: GoogleFonts.poppins(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blue.shade800,
              ),
            ),
            const SizedBox(height: 15),
            Text(
              'Follow these simple steps to effectively use the FundsEye application for patient management and Diabetic Retinopathy detection.',
              style: GoogleFonts.poppins(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 20),
            _buildStep(
              stepNumber: 1,
              title: 'Login/Sign Up',
              description: 'If you are a new user, create an account using your email and password. Existing users can simply log in with their credentials.',
              icon: Icons.login,
            ),
            _buildStep(
              stepNumber: 2,
              title: 'Add a New Patient',
              description: 'From the main screen, tap the "Add Patient" button. You will be prompted to enter patient details: Name, Age, and Gender.',
              icon: Icons.person_add,
            ),
            _buildStep(
              stepNumber: 3,
              title: 'Capture Eye Image',
              description: 'After entering patient details, you will be asked to either take a new photo of the patient\'s eye using the camera (flashlight will be on automatically for better clarity) or select an existing image from your gallery.',
              icon: Icons.camera_alt,
            ),
            _buildStep(
              stepNumber: 4,
              title: 'View Patient Report',
              description: 'Once the image is captured/selected and uploaded, the app will process it. A patient report will be generated showing the detected Diabetic Retinopathy condition and personalized medical advice.',
              icon: Icons.description,
            ),
            _buildStep(
              stepNumber: 5,
              title: 'Manage Patients',
              description: 'All added patients will be listed on the home screen. You can tap on any patient to view their detailed report at any time.',
              icon: Icons.list_alt,
            ),
            _buildStep(
              stepNumber: 6,
              title: 'Share or Print Reports',
              description: 'From the patient report screen, you have options to share the report via messaging apps (like WhatsApp) or print a physical copy for your records.',
              icon: Icons.share,
            ),
            const SizedBox(height: 20),
            Text(
              'Remember: Always ensure good lighting and clear focus when capturing eye images for accurate results. Consult a medical professional for any health concerns.',
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontStyle: FontStyle.italic,
                color: Colors.blueGrey.shade700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStep({
    required int stepNumber,
    required String title,
    required String description,
    required IconData icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            backgroundColor: Colors.blue.shade100,
            radius: 20,
            child: Icon(icon, color: Colors.blue.shade700, size: 24),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Step $stepNumber: $title',
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Colors.blue.shade700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: GoogleFonts.poppins(fontSize: 15, color: Colors.grey.shade800, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
