import 'package:flutter/material.dart';
import 'package:fundseye/widgets/addperient_popup.dart';
import 'package:fundseye/widgets/header_logo.dart';
import 'package:fundseye/widgets/home_topbar.dart';
import 'package:fundseye/widgets/patient_card.dart';
import 'package:fundseye/widgets/petient_list.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';



class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: SafeArea(
  child: Column(
    children: [
      // Logout and Help Buttons
      HomeTopBar(),

      // Header (optional, add if needed)
      // HeaderLogo(screenHeight: MediaQuery.of(context).size.height * 0.3),

      // Patient List (MUST be wrapped in Expanded)
      Expanded(
        child: PatientsList(),
      ),

      // Optional footer spacing
      const SizedBox(height: 80),
    ],
  ),
),

      // Floating Add Patient Button (Gradient)
      floatingActionButton: Container(
        width: 200,
        height: 56,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            colors: [Colors.blue.shade600, Colors.blue.shade900],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () {
             showAddPatientDialog(context);
              // Navigate to add patient screen
            },
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.person_add, color: Colors.white),
                  const SizedBox(width: 8),
                  Text(
                    'Add Patient',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                      letterSpacing: 1.1,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}

