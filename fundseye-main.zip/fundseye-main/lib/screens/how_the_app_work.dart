import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HowAppWorksScreen extends StatelessWidget {
  const HowAppWorksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'How the App Works',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Understanding FundsEye',
              style: GoogleFonts.poppins(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blue.shade800,
              ),
            ),
            const SizedBox(height: 15),
            Text(
              'FundsEye is an innovative application designed to assist in the early detection and management of Diabetic Retinopathy (DR) using artificial intelligence.',
              style: GoogleFonts.poppins(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 20),
            _buildSection(
              title: '1. Image Capture & AI Analysis',
              content: 'Users capture high-resolution images of the patient\'s eye using the device camera. This image is then processed by a pre-trained TensorFlow Lite (TFLite) model embedded within the app. The AI analyzes the image for signs of Diabetic Retinopathy.',
            ),
            _buildSection(
              title: '2. Diabetic Retinopathy Detection',
              content: 'The AI model classifies the image into one of five stages of Diabetic Retinopathy: No DR, Mild DR, Moderate DR, Severe DR, or Proliferative DR. This classification is based on patterns and features identified in the eye image.',
            ),
            _buildSection(
              title: '3. Personalized Advice & Report Generation',
              content: 'Based on the AI\'s diagnosis, the app generates a personalized medical advice. This advice, along with patient details (name, age, gender), is saved securely to Firebase Firestore and presented in a comprehensive patient report.',
            ),
            _buildSection(
              title: '4. Secure Data Storage & Access',
              content: 'All patient data and reports are stored securely in your private section of the Firebase Firestore database. This ensures that only authorized users can access the sensitive medical information.',
            ),
            _buildSection(
              title: '5. Sharing & Printing Capabilities',
              content: 'The generated patient reports can be easily shared with medical professionals or family members via messaging apps, or printed directly from the device for physical records.',
            ),
            const SizedBox(height: 20),
            Text(
              'Disclaimer: FundsEye is a supplementary tool and should not replace professional medical advice. Always consult a qualified healthcare provider for diagnosis and treatment.',
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontStyle: FontStyle.italic,
                color: Colors.red.shade700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required String content}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.blue.shade700,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            content,
            style: GoogleFonts.poppins(fontSize: 15, color: Colors.grey.shade800, height: 1.4),
          ),
        ],
      ),
    );
  }
}
