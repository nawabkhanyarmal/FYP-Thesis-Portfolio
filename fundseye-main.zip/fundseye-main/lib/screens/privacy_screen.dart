import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Privacy Policy',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Data, Your Privacy',
              style: GoogleFonts.poppins(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blue.shade800,
              ),
            ),
            const SizedBox(height: 15),
            Text(
              'At FundsEye, we are committed to protecting your privacy. This policy outlines how we handle data within the application.',
              style: GoogleFonts.poppins(fontSize: 16, height: 1.5),
            ),
            const SizedBox(height: 20),
            _buildSection(
              title: '1. User Account & Data Storage',
              content: 'Your user account is used solely to prevent bulk entries and ensure the integrity of the service. We do not store any personal data beyond what is required for app functionality.',
            ),
            _buildSection(
              title: '2. Patient Report Data',
              content: 'The application securely stores patient reports in a private section of the Firebase Firestore database. This data includes the patient\'s name, age, and the AI-generated diagnosis. This information is necessary to provide you with the app\'s core functionality—generating and accessing medical reports.',
            ),
            _buildSection(
              title: '3. Data Security & Access',
              content: 'All data is stored securely in Firebase Firestore. We implement industry-standard security measures to protect your information and ensure that only authorized users can access the data.',
            ),
            _buildSection(
              title: '4. No Other Data Stored',
              content: 'We do not collect, store, or share any other personal information from you or your device, such as your location, contacts, or browsing history. The data we handle is limited to the patient reports you create within the app.',
            ),
            const SizedBox(height: 20),
            Text(
              'By using FundsEye, you agree to the terms of this privacy policy. This policy may be updated from time to time. We encourage you to review it periodically.',
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontStyle: FontStyle.italic,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required String content}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Colors.blue.shade700,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            content,
            style: GoogleFonts.poppins(fontSize: 15, color: Colors.grey.shade800, height: 1.4),
          ),
        ],
      ),
    );
  }
}
