import 'package:flutter/material.dart';
import 'package:fundseye/model_class/firebase_options.dart';
import 'package:fundseye/screens/home_screen.dart';
import 'package:fundseye/screens/signup_screen.dart';
import 'package:fundseye/widgets/custome_button.dart';
import 'package:fundseye/widgets/custome_textfield.dart';
import 'package:fundseye/widgets/header_logo.dart';
import 'package:fundseye/widgets/signup_button.dart';
import 'package:google_fonts/google_fonts.dart';
// Make sure to create this file

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late final TextEditingController _emailController;
  late final TextEditingController _passwordController;
  bool _obscurePassword = true;
  bool _rememberMe = false;

  @override
  @override
  void dispose() {

    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();

  }

  void initState() {
    super.initState();

    _emailController = TextEditingController();
    _passwordController = TextEditingController();

  }
  Widget build(BuildContext context) {

    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: screenWidth * 0.05,
              vertical: screenHeight * 0.001,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                HeaderLogo(screenHeight: MediaQuery.of(context).size.height),

                Text(
                  'Log in',
                  style: GoogleFonts.poppins(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                Text(
                  'Please enter log in details below',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    color: Colors.grey.shade600,
                  ),
                ),
                SizedBox(height: screenHeight * 0.05),
                Text(
                  'Email',
                  style: GoogleFonts.poppins(
                      fontSize: 14, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 8),
                 CustomTextField(hintText: 'Enter your mail',
                controller: _emailController,),
                SizedBox(height: screenHeight * 0.025),
                Text(
                  'Password',
                  style: GoogleFonts.poppins(
                      fontSize: 14, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 8),
                CustomTextField(
                  controller: _passwordController,
                  hintText: 'Enter your password',
                  isPassword: true,
                  obscureText: _obscurePassword,
                  onSuffixIconTap: () {
                    setState(() {
                      _obscurePassword = !_obscurePassword;
                    });
                  },
                ),
                SizedBox(height: screenHeight * 0.02),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Checkbox(
                          value: _rememberMe,
                          onChanged: (value) {
                            setState(() {
                              _rememberMe = value ?? false;
                            });
                          },
                          activeColor: Colors.blue.shade800,
                        ),
                        Text(
                          'Remember me',
                          style: GoogleFonts.poppins(
                            color: Colors.grey.shade700,
                          ),
                        ),
                      ],
                    ),
                    TextButton(
                      onPressed: () {},
                      child: Text(
                        'Forgot password?',
                        style: GoogleFonts.poppins(
                          color: Colors.blue.shade800,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: screenHeight * 0.03),
                PrimaryButton(text: 'Log in', onPressed: ()
                {
                   final email = _emailController.text.trim();
            final password = _passwordController.text.trim();

            if (email.isEmpty || password.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Please enter email and password.')),
              );
              return;
            }

              loginWithEmail(
                email: _emailController.text,
                password: _passwordController.text,
                context: context,
                homeScreen: HomeScreen(),
              );

                }),
                SizedBox(height: screenHeight * 0.04),
                Row(
                  children: [
                    const Expanded(child: Divider()),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Text(
                        'Or',
                        style: GoogleFonts.poppins(
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ),
                    const Expanded(child: Divider()),
                  ],
                ),
                SizedBox(height: screenHeight * 0.04),
                Row(
                  children: [
                    SocialLoginButton(
                      text: 'Google',
                      assetPath: 'assets/images/google_logo.png',
                      onPressed: () 
                      {
                        signInWithGoogle(context);
                      },
                    ),
                    const SizedBox(width: 15),
                    SocialLoginButton(
                      text: 'Facebook',
                     assetPath: 'assets/images/facebook_logo.png',
                      onPressed: () {},
                    ),
                  ],
                ),
                SizedBox(height: screenHeight * 0.05),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Don't have an account? ",
                      style: GoogleFonts.poppins(color: Colors.grey.shade700),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const SignupScreen()),
                        );
                      },
                      child: Text(
                        'Sign Up',
                        style: GoogleFonts.poppins(
                          color: Colors.blue.shade800,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}