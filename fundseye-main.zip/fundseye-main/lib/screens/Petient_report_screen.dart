import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fundseye/widgets/header_logo.dart'; // Ensure this file exists
import 'package:share_plus/share_plus.dart'; // Import for sharing
import 'package:printing/printing.dart'; // Import for printing
import 'package:pdf/pdf.dart'; // Import for PDF document creation
import 'package:pdf/widgets.dart' as pw; // Alias for PDF widgets

class PatientReportScreen extends StatefulWidget {
  final String patientId; // The ID of the patient document to fetch

  const PatientReportScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<PatientReportScreen> createState() => _PatientReportScreenState();
}

class _PatientReportScreenState extends State<PatientReportScreen> {
  Map<String, dynamic>? _patientData; // Holds the fetched patient data
  bool _isLoading = true; // State to manage loading indicator
  String? _errorMessage; // State to hold any error messages

  @override
  void initState() {
    super.initState();
    _fetchPatientData(); // Start fetching data when the widget initializes
  }

  // --- Firebase Data Fetching Function ---
  Future<void> _fetchPatientData() async {
    setState(() {
      _isLoading = true; // Set loading to true before fetching
      _errorMessage = null; // Clear any previous error messages
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw Exception("User not logged in."); // Ensure user is authenticated
      }

      final userId = user.uid; // Get the current user's UID

      final patientDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('patients')
          .doc(widget.patientId)
          .get();

      if (patientDoc.exists) {
        setState(() {
          _patientData = patientDoc.data(); // Set the fetched data
          _isLoading = false; // Stop loading
        });
      } else {
        setState(() {
          _errorMessage = "Patient data not found.";
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Failed to load patient data: ${e.toString()}";
        _isLoading = false;
      });
      print('Error fetching patient data: $e');
    }
  }

  // --- Share Report Function ---
  Future<void> _shareReport() async {
    if (_patientData == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Report data not loaded yet.')),
      );
      return;
    }

    final String reportText = """
Patient Report:
Name: ${_patientData!['name'] ?? 'N/A'}
Age: ${_patientData!['age'] ?? 'N/A'}
Gender: ${_patientData!['gender'] ?? 'N/A'}
Patient ID: ${widget.patientId}
Condition: ${_patientData!['result'] ?? 'N/A'}
Medical Advice: ${_patientData!['advice'] ?? 'No advice available.'}

Note: This is AI generated report. Please consult it with your doctor.
"""; // Added the disclaimer here for sharing

    try {
      await Share.share(reportText, subject: 'Patient Medical Report');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to share report: ${e.toString()}')),
      );
      print('Error sharing report: $e');
    }
  }

  // --- Print Report Function ---
  Future<void> _printReport() async {
    if (_patientData == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Report data not loaded yet.')),
      );
      return;
    }

    final doc = pw.Document(); // Create a new PDF document

    // Add content to the PDF document
    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Patient Medical Report',
                  style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 20),
              pw.Text('Name: ${_patientData!['name'] ?? 'N/A'}', style: const pw.TextStyle(fontSize: 16)),
              pw.Text('Age: ${_patientData!['age'] ?? 'N/A'}', style: const pw.TextStyle(fontSize: 16)),
              pw.Text('Gender: ${_patientData!['gender'] ?? 'N/A'}', style: const pw.TextStyle(fontSize: 16)),
              pw.Text('Patient ID: ${widget.patientId}', style: const pw.TextStyle(fontSize: 16)),
              pw.SizedBox(height: 10),
              pw.Text('Condition: ${_patientData!['result'] ?? 'N/A'}',
                  style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: PdfColors.red700)),
              pw.SizedBox(height: 20),
              pw.Text('Medical Advice:',
                  style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
              pw.Text(_patientData!['advice'] ?? 'No advice available.',
                  style: const pw.TextStyle(fontSize: 16)),
              pw.SizedBox(height: 10), // Spacing before the disclaimer in PDF
              pw.Text('Note: This is AI generated report. Please consult it with your doctor.',
                  style: pw.TextStyle(fontSize: 12, fontStyle: pw.FontStyle.italic, color: PdfColors.grey600)), // Disclaimer for PDF
            ],
          );
        },
      ),
    );

    try {
      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => doc.save(),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to print report: ${e.toString()}')),
      );
      print('Error printing report: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);

    return Scaffold(
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: EdgeInsets.only(
              top: mediaQuery.padding.top + 20.0,
              left: 20.0,
              right: 20.0,
              bottom: mediaQuery.padding.bottom + 20.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Header Logo
                HeaderLogo(screenHeight: mediaQuery.size.height * 0.15),
                const SizedBox(height: 40),

                // Screen Title
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "Patient Report",
                    style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ),
                const SizedBox(height: 30),

                // Conditional rendering based on loading state and data availability
                _isLoading
                    ? const Center(child: CircularProgressIndicator(color: Colors.teal))
                    : _errorMessage != null
                    ? Center(
                  child: Text(
                    _errorMessage!,
                    style: const TextStyle(color: Colors.red, fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                )
                    : _patientData == null
                    ? const Center(
                  child: Text(
                    "No patient data available.",
                    style: TextStyle(color: Colors.grey, fontSize: 16),
                  ),
                )
                    : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Patient Information Section
                    _buildSectionContainer(
                      context,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildInfoRow("Name:", _patientData!['name'] ?? 'N/A'),
                          _buildInfoRow("Age:", _patientData!['age'] ?? 'N/A'),
                          _buildInfoRow("Gender:", _patientData!['gender'] ?? 'N/A'),
                          _buildInfoRow("Patient ID:", widget.patientId),
                          _buildInfoRow("Condition:", _patientData!['result'] ?? 'N/A', isCondition: true),
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),

                    // Medical Advice Section
                    _buildSectionContainer(
                      context,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.medical_services_outlined, color: Colors.teal.shade700, size: 28),
                              const SizedBox(width: 10),
                              Text(
                                "Medical Advice",
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.teal.shade700,
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 25, thickness: 1, color: Colors.grey),
                          Text(
                            _patientData!['advice'] ?? 'No advice available at this time.',
                            style: const TextStyle(fontSize: 17, height: 1.5, color: Colors.black87),
                          ),
                          const SizedBox(height: 10), // Small space before the note
                          Text(
                            'Note: This is AI generated report. Please consult it with your doctor.',
                            style: TextStyle(
                              fontSize: 14,
                              fontStyle: FontStyle.italic,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 40),

                    // Action Buttons (Share and Print)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildActionButton(
                          icon: Icons.share,
                          label: 'Share',
                          onPressed: _shareReport,
                        ),
                        _buildActionButton(
                          icon: Icons.print,
                          label: 'Print',
                          onPressed: _printReport,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
          // --- Custom Back Button ---
          Positioned(
            top: mediaQuery.padding.top + 10,
            left: 10,
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: Colors.black, size: 28),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ],
      ),
    );
  }

  // Helper method to create a consistent row for patient information
  Widget _buildInfoRow(String label, String value, {bool isCondition = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: label,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),
            TextSpan(
              text: " $value",
              style: TextStyle(
                fontSize: 18,
                color: isCondition ? Colors.red.shade700 : Colors.black87,
                fontWeight: isCondition ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to create a consistent container for sections, mimicking iOS cards
  Widget _buildSectionContainer(BuildContext context, Widget child) {
    return Container(
      padding: const EdgeInsets.all(20.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: child,
    );
  }

  // Helper method to create stylish action buttons
  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.teal.shade50,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.teal.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 5,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: IconButton(
            icon: Icon(icon, color: Colors.teal.shade700, size: 30),
            onPressed: onPressed,
            padding: const EdgeInsets.all(15),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: Colors.grey[700],
          ),
        ),
      ],
    );
  }
}
