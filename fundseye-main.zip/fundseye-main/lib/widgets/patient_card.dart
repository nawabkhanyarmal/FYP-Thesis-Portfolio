import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fundseye/screens/Petient_report_screen.dart';

class PatientCard extends StatelessWidget {
  final String name;
  final String gender;
  final String age;
  final String patientId;

  const PatientCard({
    Key? key,
    required this.name,
    required this.gender,
    required this.age,
    required this.patientId,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    IconData genderIcon = gender.toLowerCase() == 'female'
        ? Icons.female
        : gender.toLowerCase() == 'male'
            ? Icons.male
            : Icons.person;

    Color genderIconColor = gender.toLowerCase() == 'female'
        ? Colors.pink
        : gender.toLowerCase() == 'male'
            ? Colors.blue
            : Colors.grey;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PatientReportScreen(
              patientId: patientId, // Only pass the patientId now
            ),
          ),
        );
      },
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.blue.shade50),
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4),
            leading: CircleAvatar(
              backgroundColor: genderIconColor,
              child: Icon(genderIcon, color: Colors.white),
            ),
            title: Text(
              name,
              style: GoogleFonts.poppins(
                fontSize: 17,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
            subtitle: Text(
              'Sex: $gender • Age: $age\nTap to view report',
              style: GoogleFonts.poppins(
                fontSize: 13,
                color: Colors.grey.shade600,
              ),
            ),
            trailing: Icon(Icons.chevron_right, color: Colors.grey.shade500),
          ),
        ),
      ),
    );
  }
}
