import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fundseye/model_class/firebase_options.dart'; // Assuming logoutAndRedirectToLogin is here
import 'package:fundseye/screens/how_the_app_work.dart';
import 'package:fundseye/screens/how_to_use_screen.dart';
import 'package:fundseye/screens/privacy_screen.dart';
import 'package:fundseye/widgets/header_logo.dart';
import 'package:google_fonts/google_fonts.dart'; // Import GoogleFonts

class HomeTopBar extends StatelessWidget {
  const HomeTopBar({super.key});

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return SizedBox(
      height: screenHeight * 0.2,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Logo in the center
          Positioned(
            top: 20,
            left: 0,
            right: 0,
            child: Center(
              child: HeaderLogo(screenHeight: screenHeight),
            ),
          ),

          // Logout Button - top left
          Positioned(
            top: 10,
            left: 16,
            child: IconButton(
              tooltip: 'Logout',
                onPressed: () async {
                await logoutAndRedirectToLogin(context);
              },
              icon: Icon(Icons.logout, color: Colors.red.shade700),
            ),
          ),

          // Help Button - top right
          Positioned(
            top: 10,
            right: 16,
            child: IconButton(
              tooltip: 'Help',
              onPressed: () {
                // --- Help logic: Show popup ---
                showDialog(
                  context: context,
                  builder: (BuildContext dialogContext) {
                    return AlertDialog(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      title: Text(
                        'How can we help?',
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: Colors.blue.shade700,
                        ),
                      ),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ListTile(
                            leading: Icon(Icons.info_outline, color: Colors.blue.shade400),
                            title: Text('How the App Works', style: GoogleFonts.poppins()),
                            onTap: () {
                              Navigator.pop(dialogContext); // Close the dialog
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const HowAppWorksScreen()),
                              );
                            },
                          ),
                          ListTile(
                            leading: Icon(Icons.lightbulb_outline, color: Colors.orange.shade400),
                            title: Text('How to Use the App', style: GoogleFonts.poppins()),
                            onTap: () {
                              Navigator.pop(dialogContext); // Close the dialog
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const HowToUseScreen()),
                              );
                            },
                          ),
                          ListTile(
                            leading: Icon(Icons.info_outline, color: Colors.blue.shade400),
                            title: Text('App Privacy Policy', style: GoogleFonts.poppins()),
                            onTap: () {
                              Navigator.pop(dialogContext); // Close the dialog
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const PrivacyPolicyScreen()),
                              );
                            },
                          ),
                          // New "Delete Account" option inside the help dialog
                          ListTile(
                            leading: Icon(Icons.delete_forever, color: Colors.red.shade700),
                            title: Text('Delete My Account', style: GoogleFonts.poppins()),
                            onTap: () {
                              Navigator.pop(dialogContext); // Close the help dialog first
                              _showDeleteConfirmationDialog(context); // Then show the delete dialog
                            },
                          ),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(dialogContext); // Close the dialog
                          },
                          child: Text(
                            'Close',
                            style: GoogleFonts.poppins(color: Colors.grey.shade700),
                          ),
                        ),
                      ],
                    );
                  },
                );
                // --- End Help logic ---
              },
              icon: Icon(Icons.help_outline, color: Colors.blue.shade800),
            ),
          ),
        ],
      ),
    );
  }

  // A separate function to handle the confirmation dialog
  void _showDeleteConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          title: Text(
            'Confirm Account Deletion',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold,
              color: Colors.red.shade700,
            ),
          ),
          content: Text(
            'Are you sure you want to delete your account? All of your data will be permanently lost.',
            style: GoogleFonts.poppins(),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext); // Close the dialog
              },
              child: Text(
                'Cancel',
                style: GoogleFonts.poppins(color: Colors.grey.shade700),
              ),
            ),
            TextButton(
  onPressed: () async { 
    await deleteAccount(context);
  },
  child: Text(
    'Delete',
    style: GoogleFonts.poppins(
      color: Colors.red.shade700,
      fontWeight: FontWeight.bold,
    ),
  ),
),
          ],
        );
      },
    );
  }
}
