import 'package:flutter/material.dart';
import 'package:camera/camera.dart'; // Import the camera package
import 'package:google_fonts/google_fonts.dart';

// Global variable to store available cameras
// This needs to be initialized once, typically in main() or before the app runs.
// (As discussed, this is handled in your main.dart)
List<CameraDescription> cameras = [];

class CustomCameraScreen extends StatefulWidget {
  const CustomCameraScreen({super.key});

  @override
  State<CustomCameraScreen> createState() => _CustomCameraScreenState();
}

class _CustomCameraScreenState extends State<CustomCameraScreen> {
  CameraController? _controller;
  bool _isCameraInitialized = false;
  bool _isCapturing = false; // To prevent multiple taps during capture

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    // Ensure cameras are initialized globally before this screen is accessed.
    // This 'cameras' list is populated in your main.dart file.
    if (cameras.isEmpty) {
      try {
        cameras = await availableCameras();
      } on CameraException catch (e) {
        print("Error getting available cameras: $e");
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error accessing cameras: ${e.description}')),
          );
          Navigator.of(context).pop(); // Go back if camera initialization fails
        }
        return;
      }
    }

    // Try to find a back camera, otherwise use the first available camera
    final CameraDescription? backCamera = cameras.firstWhere(
      (camera) => camera.lensDirection == CameraLensDirection.back,
      orElse: () => cameras.first, // Fallback to first camera if no back camera found
    );

    if (backCamera == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No camera found on this device.')),
        );
        Navigator.of(context).pop();
      }
      return;
    }

    _controller = CameraController(
      backCamera, // Use the back camera for eye images
      ResolutionPreset.high, // High resolution for better image quality
      enableAudio: false, // No audio needed for eye images
    );

    try {
      await _controller!.initialize();
      // Set flash mode to torch (always on) after successful initialization
      await _controller!.setFlashMode(FlashMode.torch);
      setState(() {
        _isCameraInitialized = true;
      });
    } on CameraException catch (e) {
      print("Error initializing camera: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error initializing camera: ${e.description}')),
        );
        Navigator.of(context).pop(); // Go back if camera initialization fails
      }
    }
  }

  Future<void> _takePicture() async {
    // Prevent taking picture if camera not ready or already capturing
    if (!_isCameraInitialized || _controller == null || _controller!.value.isTakingPicture || _isCapturing) {
      return;
    }

    setState(() {
      _isCapturing = true; // Indicate that a picture is being captured
    });

    try {
      final XFile file = await _controller!.takePicture();
      if (mounted) {
        Navigator.of(context).pop(file); // Return the captured image file to the previous screen
      }
    } on CameraException catch (e) {
      print("Error taking picture: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error taking picture: ${e.description}')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isCapturing = false; // Reset capturing state
        });
      }
    }
  }

  @override
  void dispose() {
    _controller?.dispose(); // Dispose the camera controller when the widget is removed
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isCameraInitialized) {
      // Show a loading indicator while the camera is initializing
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: CircularProgressIndicator(color: Colors.blue.shade700),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Camera Preview fills the entire screen
          Positioned.fill(
            child: CameraPreview(_controller!),
          ),

          // Capture Button at the bottom center
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 40.0),
              child: FloatingActionButton(
                onPressed: _isCapturing ? null : _takePicture, // Disable button while capturing
                backgroundColor: _isCapturing ? Colors.grey : Colors.blue.shade700,
                child: _isCapturing
                    ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 3)
                    : const Icon(Icons.camera_alt, color: Colors.white, size: 36),
              ),
            ),
          ),

          // Back Button (Top Left)
          Positioned(
            top: MediaQuery.of(context).padding.top + 10,
            left: 10,
            child: IconButton(
              icon: const Icon(Icons.close, color: Colors.white, size: 30), // 'X' icon for closing
              onPressed: () => Navigator.of(context).pop(), // Close camera screen without returning an image
            ),
          ),
        ],
      ),
    );
  }
}
