import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fundseye/widgets/patient_card.dart';

class PatientsList extends StatelessWidget {
  const PatientsList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final userId = FirebaseAuth.instance.currentUser?.uid;

    if (userId == null) {
      return const Center(child: Text("❌ User not logged in."));
    }

    final CollectionReference patientsRef = FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('patients');

    return StreamBuilder<QuerySnapshot>(
      stream: patientsRef.orderBy('createdAt', descending: true).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(
            child: Text(
              'No patients found.\nPlease add a patient.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 16),
            ),
          );
        }

        final docs = snapshot.data!.docs;

        return ListView.builder(
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final doc = docs[index];
            final data = doc.data() as Map<String, dynamic>;
            final patientId = doc.id;
            final name = data['name'] ?? 'Unknown';
            final gender = data['gender'] ?? 'Unknown';
            final age = data['age'] ?? 'N/A';

            return PatientCard(
              patientId: patientId,
              name: name,
              gender: gender,
              age: age,
            );
          },
        );
      },
    );
  }
}
