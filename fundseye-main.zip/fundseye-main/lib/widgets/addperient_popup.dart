import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:fundseye/model_class/firebase_options.dart';
import 'package:fundseye/widgets/custum_camera.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart'; // Still needed for gallery option
import 'package:fundseye/model_class/predict_and_save.dart';
 // Import your custom camera screen

void showAddPatientDialog(BuildContext context) {
  final nameController = TextEditingController();
  final ageController = TextEditingController();
  String? selectedGender;
  XFile? pickedImage;
  bool isUploading = false;

  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (dialogContext) {
      return StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            backgroundColor: Colors.white,
            title: Center(
              child: Text(
                'Add Patient',
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                  color: Colors.blue.shade700,
                  letterSpacing: 1.2,
                ),
              ),
            ),
            content: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 8.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(
                        hintText: 'Patient Name',
                        prefixIcon: const Icon(Icons.person),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: ageController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        hintText: 'Age',
                        prefixIcon: const Icon(Icons.cake),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: DropdownButtonFormField<String>(
                        value: selectedGender,
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.wc, color: Colors.grey.shade600),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                        ),
                        hint: Text('Select Gender', style: GoogleFonts.poppins(color: Colors.grey.shade400)),
                        items: ['Male', 'Female', 'Other'].map((gender) {
                          return DropdownMenuItem(
                            value: gender,
                            child: Text(gender, style: GoogleFonts.poppins()),
                          );
                        }).toList(),
                        onChanged: (val) => setState(() => selectedGender = val),
                      ),
                    ),
                    const SizedBox(height: 18),
                    GestureDetector(
                      onTap: () async {
                        final source = await showDialog<ImageSource>(
                          context: context,
                          builder: (ctx) => SimpleDialog(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            title: Text('Choose image source', style: GoogleFonts.poppins()),
                            children: [
                              SimpleDialogOption(
                                // This option will now navigate to your CustomCameraScreen
                                onPressed: () => Navigator.pop(ctx, ImageSource.camera),
                                child: Row(children: [
                                  Icon(Icons.camera_alt, color: Colors.blue.shade400),
                                  const SizedBox(width: 8),
                                  Text('Camera', style: GoogleFonts.poppins()),
                                ]),
                              ),
                              SimpleDialogOption(
                                // This option will still use ImagePicker for gallery
                                onPressed: () => Navigator.pop(ctx, ImageSource.gallery),
                                child: Row(children: [
                                  Icon(Icons.photo, color: Colors.green.shade400),
                                  const SizedBox(width: 8),
                                  Text('Gallery', style: GoogleFonts.poppins()),
                                ]),
                              ),
                            ],
                          ),
                        );

                        if (source == null) return;

                        XFile? image;
                        if (source == ImageSource.camera) {
                          // Navigate to your CustomCameraScreen to capture the image
                          image = await Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const CustomCameraScreen()),
                          );
                        } else {
                          // Use ImagePicker for selecting from the gallery
                          final ImagePicker picker = ImagePicker();
                          image = await picker.pickImage(source: source);
                        }

                        if (image != null) {
                          setState(() => pickedImage = image);
                        }
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: pickedImage == null ? Colors.blue.shade200 : Colors.green.shade400,
                            width: 1.2,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              pickedImage == null ? Icons.image : Icons.check_circle,
                              color: pickedImage == null ? Colors.blue.shade400 : Colors.green.shade400,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              pickedImage == null ? 'Pick Eye Image' : 'Image Selected',
                              style: GoogleFonts.poppins(
                                color: pickedImage == null ? Colors.blue.shade700 : Colors.green.shade700,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue.shade700,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          elevation: 2,
                        ),
                        onPressed: isUploading
                            ? null
                            : () async {
                                if (nameController.text.isEmpty ||
                                    ageController.text.isEmpty ||
                                    selectedGender == null ||
                                    pickedImage == null) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Please fill all fields and add an image')),
                                  );
                                  return;
                                }

                                setState(() => isUploading = true);

                                try {
                                  await predictAndSavePatient(
                                    name: nameController.text.trim(),
                                    age: ageController.text.trim(),
                                    gender: selectedGender!,
                                    imageFile: pickedImage!,
                                  );

                                  if (!context.mounted) return;

                                  Navigator.of(dialogContext).pop();
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Patient added successfully!')),
                                  );
                                } catch (e) {
                                  setState(() => isUploading = false);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('Upload failed: $e')),
                                  );
                                }
                              },
                        child: isUploading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2.5,
                                ),
                              )
                            : Text(
                                'Submit',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  color: Colors.white,
                                  letterSpacing: 1.1,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    },
  );
}
