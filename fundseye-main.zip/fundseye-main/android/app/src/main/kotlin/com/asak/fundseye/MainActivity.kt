package com.asak.fundseye

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
